import express from 'express';
import {createUser,updateUser,getUser} from '../controllers/userController.js';
import authenticateBasicAuth from '../middleware/authenticationMiddleware.js';

const router = express.Router();
// Create a new user
router.post('/v1/user', createUser);

// Update user information
router.put('/v1/user/self', authenticateBasicAuth, updateUser);

// Get user information
router.get('/v1/user/self', authenticateBasicAuth, getUser);

export default router;